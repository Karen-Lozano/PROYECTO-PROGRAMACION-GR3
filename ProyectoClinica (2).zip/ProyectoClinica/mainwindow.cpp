#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>
#include <QFile>
#include <QTextStream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->tableWidget->setColumnCount(8);
    ui->tableWidget->setHorizontalHeaderLabels({
        "ID","Nombre","Dueño","Especie","Enfermedad",
        "Ingreso","Salida","Costo"
    });

    cargarArchivo();
    mostrarTabla();
}

MainWindow::~MainWindow()
{
    delete ui;
}

// ---------------- LIMPIAR ----------------
void MainWindow::limpiarCampos()
{
    ui->txtId->clear();
    ui->txtNombre->clear();
    ui->txtDueno->clear();
    ui->txtEnfermedad->clear();
    ui->txtCosto->clear();
    ui->cmbEspecie->setCurrentIndex(0);
    ui->dtIngreso->setDateTime(QDateTime::currentDateTime());
    ui->dtSalida->setDateTime(QDateTime::currentDateTime());
    indiceActual = -1;
}

// ---------------- AGREGAR ----------------
void MainWindow::on_btnAgregar_clicked()
{
    // VALIDACIONES
    if (ui->txtId->text().trimmed().isEmpty()) {
        QMessageBox::warning(this, "Validación", "Ingrese el ID");
        ui->txtId->setFocus();
        return;
    }

    if (ui->txtNombre->text().trimmed().isEmpty()) {
        QMessageBox::warning(this, "Validación", "Ingrese el nombre de la mascota");
        ui->txtNombre->setFocus();
        return;
    }

    if (ui->txtDueno->text().trimmed().isEmpty()) {
        QMessageBox::warning(this, "Validación", "Ingrese el nombre del dueño");
        ui->txtDueno->setFocus();
        return;
    }

    if (ui->cmbEspecie->currentIndex() == 0) {
        QMessageBox::warning(this, "Validación", "Seleccione una especie");
        ui->cmbEspecie->setFocus();
        return;
    }

    if (ui->txtEnfermedad->text().trimmed().isEmpty()) {
        QMessageBox::warning(this, "Validación", "Ingrese la enfermedad");
        ui->txtEnfermedad->setFocus();
        return;
    }

    if (ui->txtCosto->text().trimmed().isEmpty()) {
        QMessageBox::warning(this, "Validación", "Ingrese el costo");
        ui->txtCosto->setFocus();
        return;
    }

    // CONVERTIR COSTO
    bool ok;
    double costo = ui->txtCosto->text().toDouble(&ok);
    if (!ok || costo <= 0) {
        QMessageBox::warning(this, "Validación", "Ingrese un costo válido");
        ui->txtCosto->setFocus();
        return;
    }

    // VALIDAR ID DUPLICADO
    int id = ui->txtId->text().toInt();
    for (const Mascota &m : listaMascotas) {
        if (m.id == id) {
            QMessageBox::warning(this, "Error", "El ID ya existe");
            ui->txtId->setFocus();
            return;
        }
    }

    // CREAR MASCOTA
    Mascota m;
    m.id = id;
    m.nombre = ui->txtNombre->text();
    m.dueno = ui->txtDueno->text();
    m.especie = ui->cmbEspecie->currentText();
    m.enfermedad = ui->txtEnfermedad->text();
    m.fechaIngreso = ui->dtIngreso->dateTime();
    m.fechaSalida = ui->dtSalida->dateTime();
    m.costo = costo;

    // GUARDAR
    listaMascotas.push_back(m);
    guardarArchivo();
    mostrarTabla();
    limpiarCampos();

    QMessageBox::information(this, "Éxito", "Mascota registrada correctamente");
}


// ---------------- BUSCAR (COMO ANTES) ----------------
void MainWindow::on_btnBuscar_clicked()
{
    int id = ui->txtId->text().toInt();

    for (int i = 0; i < listaMascotas.size(); i++) {
        if (listaMascotas[i].id == id) {

            indiceActual = i;

            ui->txtNombre->setText(listaMascotas[i].nombre);
            ui->txtDueno->setText(listaMascotas[i].dueno);
            ui->cmbEspecie->setCurrentText(listaMascotas[i].especie);
            ui->txtEnfermedad->setText(listaMascotas[i].enfermedad);
            ui->dtIngreso->setDateTime(listaMascotas[i].fechaIngreso);
            ui->dtSalida->setDateTime(listaMascotas[i].fechaSalida);
            ui->txtCosto->setText(QString::number(listaMascotas[i].costo,'f',2));

            QMessageBox::information(this,"Buscar","Mascota encontrada");
            return;
        }
    }

    QMessageBox::warning(this,"Buscar","Mascota no encontrada");
}

// ---------------- ACTUALIZAR ----------------
void MainWindow::on_btnActualizar_clicked()
{
    if (indiceActual == -1) {
        QMessageBox::warning(this,"Actualizar","Primero busque una mascota");
        return;
    }

    listaMascotas[indiceActual].nombre = ui->txtNombre->text();
    listaMascotas[indiceActual].dueno = ui->txtDueno->text();
    listaMascotas[indiceActual].especie = ui->cmbEspecie->currentText();
    listaMascotas[indiceActual].enfermedad = ui->txtEnfermedad->text();
    listaMascotas[indiceActual].fechaIngreso = ui->dtIngreso->dateTime();
    listaMascotas[indiceActual].fechaSalida = ui->dtSalida->dateTime();
    listaMascotas[indiceActual].costo = ui->txtCosto->text().toDouble();

    guardarArchivo();
    mostrarTabla();
    limpiarCampos();

    QMessageBox::information(this,"Actualizar","Datos actualizados");
}

// ---------------- ELIMINAR ----------------
void MainWindow::on_btnEliminar_clicked()
{
    if (indiceActual == -1) {
        QMessageBox::warning(this,"Eliminar","Primero busque una mascota");
        return;
    }

    if (QMessageBox::question(this,"Eliminar",
                              "¿Desea eliminar esta mascota?",
                              QMessageBox::Yes | QMessageBox::No) == QMessageBox::No)
        return;

    listaMascotas.erase(listaMascotas.begin() + indiceActual);
    guardarArchivo();
    mostrarTabla();
    limpiarCampos();

    QMessageBox::information(this,"Eliminar","Mascota eliminada");
}

// ---------------- MOSTRAR ----------------
void MainWindow::on_btnMostrar_clicked()
{
    mostrarTabla();
}

// ---------------- TABLA ----------------
void MainWindow::mostrarTabla()
{
    ui->tableWidget->setRowCount(listaMascotas.size());

    for (int i = 0; i < listaMascotas.size(); i++) {
        ui->tableWidget->setItem(i,0,new QTableWidgetItem(QString::number(listaMascotas[i].id)));
        ui->tableWidget->setItem(i,1,new QTableWidgetItem(listaMascotas[i].nombre));
        ui->tableWidget->setItem(i,2,new QTableWidgetItem(listaMascotas[i].dueno));
        ui->tableWidget->setItem(i,3,new QTableWidgetItem(listaMascotas[i].especie));
        ui->tableWidget->setItem(i,4,new QTableWidgetItem(listaMascotas[i].enfermedad));
        ui->tableWidget->setItem(i,5,new QTableWidgetItem(listaMascotas[i].fechaIngreso.toString("dd/MM/yyyy hh:mm")));
        ui->tableWidget->setItem(i,6,new QTableWidgetItem(listaMascotas[i].fechaSalida.toString("dd/MM/yyyy hh:mm")));
        ui->tableWidget->setItem(i,7,new QTableWidgetItem(QString::number(listaMascotas[i].costo,'f',2)));
    }
}

// ---------------- ARCHIVO ----------------
void MainWindow::guardarArchivo()
{
    QFile f("mascotas.txt");
    if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) return;

    QTextStream out(&f);
    for (const Mascota &m : listaMascotas) {
        out << m.id << "|"
            << m.nombre << "|"
            << m.dueno << "|"
            << m.especie << "|"
            << m.enfermedad << "|"
            << m.fechaIngreso.toString(Qt::ISODate) << "|"
            << m.fechaSalida.toString(Qt::ISODate) << "|"
            << m.costo << "\n";
    }
    f.close();
}

void MainWindow::cargarArchivo()
{
    QFile f("mascotas.txt");
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) return;

    QTextStream in(&f);
    while (!in.atEnd()) {
        QStringList d = in.readLine().split("|");
        if (d.size() == 8) {
            Mascota m;
            m.id = d[0].toInt();
            m.nombre = d[1];
            m.dueno = d[2];
            m.especie = d[3];
            m.enfermedad = d[4];
            m.fechaIngreso = QDateTime::fromString(d[5], Qt::ISODate);
            m.fechaSalida = QDateTime::fromString(d[6], Qt::ISODate);
            m.costo = d[7].toDouble();
            listaMascotas.push_back(m);
        }
    }
    f.close();
}
