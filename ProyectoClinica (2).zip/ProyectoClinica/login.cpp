#include "login.h"
#include "ui_login.h"
#include <QMessageBox>
#include <QLineEdit>

Login::Login(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Login)
{
    ui->setupUi(this);

    ui->txtPass->setEchoMode(QLineEdit::Password);

    // ENTER para login
    connect(ui->txtPass, &QLineEdit::returnPressed,
            this, &Login::on_btnLogin_clicked);

    // ESTILOS
    this->setStyleSheet(R"(
        QDialog {
            background-color: #F8FAFC;
        }
        QLabel {
            font-size: 14px;
            font-weight: bold;
            color: #2C3E50;
        }
        QLineEdit {
            border: 2px solid #A5B4FC;
            border-radius: 10px;
            padding: 6px;
        }
        QLineEdit:focus {
            border-color: #6366F1;
        }
        QPushButton {
            background-color: #6366F1;
            color: white;
            border-radius: 12px;
            padding: 8px;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #4F46E5;
        }
    )");
}

Login::~Login()
{
    delete ui;
}

void Login::on_btnLogin_clicked()
{
    QString user = ui->txtUser->text().trimmed();
    QString pass = ui->txtPass->text();

    if(user.isEmpty() || pass.isEmpty()){
        QMessageBox::warning(this, "Error", "Debe completar todos los campos");
        ui->txtUser->setFocus();
        return;
    }

    if(user == "admin" && pass == "1234"){
        accept();
    } else {
        QMessageBox::warning(this, "Error", "Usuario o contraseña incorrectos");
        ui->txtUser->clear();
        ui->txtPass->clear();
        ui->txtUser->setFocus();
    }
}

