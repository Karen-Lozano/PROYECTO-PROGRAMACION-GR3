#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDateTime>
#include <vector>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

struct Mascota {
    int id;
    QString nombre;
    QString dueno;
    QString especie;
    QString enfermedad;
    QDateTime fechaIngreso;
    QDateTime fechaSalida;
    double costo;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_btnAgregar_clicked();
    void on_btnBuscar_clicked();
    void on_btnActualizar_clicked();
    void on_btnEliminar_clicked();
    void on_btnMostrar_clicked();

private:
    Ui::MainWindow *ui;
    std::vector<Mascota> listaMascotas;
    int indiceActual = -1;   // ⭐ CLAVE PARA BUSCAR / ACTUALIZAR / ELIMINAR

    void limpiarCampos();
    void mostrarTabla();
    void guardarArchivo();
    void cargarArchivo();
};

#endif // MAINWINDOW_H

